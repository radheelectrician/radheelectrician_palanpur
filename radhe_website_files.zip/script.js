
const card = document.getElementById('card');
if(card){
  card.addEventListener('mousemove', (e)=>{
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width/2;
    const y = e.clientY - rect.top - rect.height/2;
    const rx = (x / rect.width) * 20;
    const ry = (y / rect.height) * -10;
    card.style.setProperty('--rx', rx + 'deg');
    card.style.transform = `rotateX(${ry}deg) rotateY(${rx}deg) scale(1.02)`;
    card.classList.add('is-tilt');
  });
  card.addEventListener('mouseleave', ()=>{
    card.style.transform = 'none';
    card.style.setProperty('--rx','0deg');
    card.classList.remove('is-tilt');
  });
  card.addEventListener('click', ()=>{
    card.classList.toggle('flipped');
    if(card.classList.contains('flipped')){
      card.querySelector('.card-front').style.transform='rotateY(180deg)';
      card.querySelector('.card-back').style.transform='rotateY(360deg)';
    } else {
      card.querySelector('.card-front').style.transform='rotateY(0deg)';
      card.querySelector('.card-back').style.transform='rotateY(180deg)';
    }
  });
}
